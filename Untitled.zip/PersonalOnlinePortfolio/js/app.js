$(document).foundation();

$(document).ready(function(){
	if($(window).scrollTop() > 0) {
        $('header').addClass('js-has-background');
    } else {
    	$('header').removeClass('js-has-background');	
    }
});

$(window).on('load', function() {

	$(window).on('scroll', function() {
	    if($(window).scrollTop() > 0) {
	        $('header').addClass('js-has-background');
	    } else {
	    	$('header').removeClass('js-has-background');	
	    }
	});
});